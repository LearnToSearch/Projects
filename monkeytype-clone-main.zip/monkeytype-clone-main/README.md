# monkeytype-clone

Test your typing speed. Deployed at: https://siddhartha254.github.io/monkeytype-clone/
